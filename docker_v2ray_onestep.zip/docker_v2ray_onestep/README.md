
#快速部署v2ray+ws+tls

1. 准备域名
2. 准备ssl证书
3. 替换v2ray配置文件内uuid
4. 替换/config/nginx/conf.d/v2ray_ws_tls.conf文件的server_name字段
5. 替换config/nginx/conf.d/certs/certs.key // config/nginx/conf.d/certs/certs.pem内容（ssl证书）
6. docker-compose up -d 启动


-------



> 安装docker-compose

```

curl -L "https://github.com/docker/compose/releases/download/1.23.2/
docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

chmod +x /usr/local/bin/docker-compose

ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

$ docker-compose --version
docker-compose version 1.23.2, build 1110ad01

```
