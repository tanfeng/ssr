/etc/init.d/shadowsocks restart
