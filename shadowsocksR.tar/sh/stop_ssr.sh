/etc/init.d/shadowsocks stop
