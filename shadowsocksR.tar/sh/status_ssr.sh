/etc/init.d/shadowsocks status
