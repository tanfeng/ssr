/etc/init.d/shadowsocks start
